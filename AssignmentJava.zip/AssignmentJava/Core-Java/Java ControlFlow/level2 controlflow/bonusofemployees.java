import java.util.Scanner;
class main {
  public static void main(String[] args){
    Scanner sc=new Scanner(System.in);
    double salary=sc.nextDouble();
    int years=sc.nextInt();

    if(years>5){
      double bonus = salary * 0.05;
      System.out.println("Bonus = "+bonus);
    } else {
      System.out.println("No bonus");
    }
  }
}
