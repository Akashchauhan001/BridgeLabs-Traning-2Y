import java.util.*;
class Q8_BMI {
    public static double calculateBMI(double weight, double heightCm) {
        double heightM = heightCm / 100.0;
        return weight / (heightM * heightM);
    }
    public static String getStatus(double bmi) {
        if (bmi < 18.5) return "Underweight";
        else if (bmi < 25) return "Normal";
        else if (bmi < 30) return "Overweight";
        else return "Obese";
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double[][] arr = new double[10][3];
        String[] status = new String[10];
        for (int i = 0; i < 10; i++) {
            arr[i][0] = sc.nextDouble();
            arr[i][1] = sc.nextDouble();
            arr[i][2] = calculateBMI(arr[i][0], arr[i][1]);
            status[i] = getStatus(arr[i][2]);
        }
        for (int i = 0; i < 10; i++) {
            System.out.println("Weight: " + arr[i][0] + " Height: " + arr[i][1] + " BMI: " + arr[i][2] + " Status: " + status[i]);
        }
    }
}