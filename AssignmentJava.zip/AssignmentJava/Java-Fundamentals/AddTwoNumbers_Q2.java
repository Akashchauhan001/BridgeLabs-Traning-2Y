import java.util.*;

public class AddTwoNumbers_Q2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int first = sc.nextInt();
        int second = sc.nextInt();
        int sum = first + second;
        System.out.println("Sum of two numbers is: "+ sum);
    }
    
}
